<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin_auth.php';

// Invoice list page: ensure automatic invoices exist, sync statuses, and apply filters.
ensure_automatic_invoices_for_all_students();
sync_all_invoice_statuses();

$filters = [
    'search' => trim($_GET['search'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
];
$where = [];
$params = [];
if ($filters['search'] !== '') {
    $where[] = "(i.invoice_number LIKE ? OR s.matricule LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)";
    $like = '%' . $filters['search'] . '%';
    array_push($params, $like, $like, $like, $like);
}
if (in_array($filters['status'], ['unpaid', 'partially_paid', 'paid', 'late'], true)) {
    $where[] = 'i.status = ?';
    $params[] = $filters['status'];
}

$sql = "SELECT i.*, s.matricule, CONCAT(s.first_name, ' ', s.last_name) AS student_name
        FROM invoices i
        JOIN students s ON s.id = i.student_id";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY i.created_at DESC';
$invoices = query_all($sql, $params);

$pageTitle = 'Factures';
$layout = 'admin';
$active = 'invoices';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1>Factures</h1>
        <p class="muted">Factures generees automatiquement et visibles par les etudiants.</p>
    </div>
    <a class="btn btn-primary" href="<?= h(url('admin/generate_invoice.php')) ?>">Generer manuellement</a>
</div>

<form class="card filter-card" method="get">
    <div class="form-grid">
        <div class="form-row"><label for="search">Recherche</label><input id="search" name="search" value="<?= h($filters['search']) ?>"></div>
        <div class="form-row">
            <label for="status">Statut</label>
            <select id="status" name="status">
                <option value="">Tous</option>
                <?php foreach (['unpaid', 'partially_paid', 'paid', 'late'] as $status): ?>
                    <option value="<?= h($status) ?>" <?= $filters['status'] === $status ? 'selected' : '' ?>><?= h([
                        'unpaid' => 'Non payee',
                        'partially_paid' => 'Partiellement payee',
                        'paid' => 'Payee',
                        'late' => 'En retard',
                    ][$status]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="actions">
        <button class="btn btn-primary" type="submit">Filtrer</button>
        <a class="btn btn-secondary" href="<?= h(url('admin/invoices.php')) ?>">Effacer</a>
    </div>
</form>

<div class="table-wrap">
    <table>
        <thead><tr><th>Facture</th><th>Matricule</th><th>Total</th><th>Paye</th><th>Reste</th><th>Echeance</th><th>Statut</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($invoices as $invoice): ?>
            <tr>
                <td><?= h($invoice['invoice_number']) ?></td>
                <td><?= h($invoice['matricule'] . ' - ' . $invoice['student_name']) ?></td>
                <td><?= money($invoice['total_amount']) ?></td>
                <td><?= money($invoice['paid_amount']) ?></td>
                <td><?= money($invoice['remaining_amount']) ?></td>
                <td><?= h($invoice['due_date'] ?? '') ?></td>
                <td><?= badge($invoice['status']) ?></td>
                <td class="actions">
                    <a class="btn btn-secondary btn-small" href="<?= h(url('admin/view_invoice.php?id=' . $invoice['id'])) ?>">Voir</a>
                    <a class="btn btn-secondary btn-small" href="<?= h(url('admin/invoice_pdf.php?id=' . $invoice['id'])) ?>">PDF</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
