<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin_auth.php';
require_once __DIR__ . '/../includes/pdf.php';

// Agent PDF endpoint for downloading an invoice snapshot.
$invoiceId = (int)($_GET['id'] ?? 0);
sync_invoice_status($invoiceId);
$invoice = query_one(
    "SELECT i.*, s.matricule, s.first_name, s.last_name, s.program, s.level, s.academic_year
     FROM invoices i
     JOIN students s ON s.id = i.student_id
     WHERE i.id = ?",
    [$invoiceId]
);
if (!$invoice) {
    flash('danger', 'Facture introuvable.');
    redirect('admin/invoices.php');
}

$items = query_all('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY fee_type ASC, id ASC', [$invoiceId]);
$payments = query_all(
    "SELECT p.*, ii.fee_name
     FROM payments p
     LEFT JOIN invoice_items ii ON ii.id = p.invoice_item_id
     WHERE p.invoice_id = ?
     ORDER BY p.submitted_at DESC",
    [$invoiceId]
);

send_invoice_pdf($invoice, $items, $payments);
