<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin_auth.php';

// Agent dashboard: aggregate finance metrics and pending payments for the landing view.
$payload = admin_dashboard_payload();
$stats = $payload['stats'];
$pendingPayments = $payload['pending_payments'];

$pageTitle = 'Tableau de bord agent';
$layout = 'admin';
$active = 'dashboard';
require __DIR__ . '/../includes/header.php';
?>
<section data-dashboard-api="<?= h(url('api/admin_dashboard_data.php')) ?>" data-dashboard-type="admin">
    <div class="page-header">
        <div>
            <h1>Tableau de bord agent</h1>
            <p class="muted">Vue financiere et paiements en attente.</p>
        </div>
        <a class="btn btn-primary" href="<?= h(url('admin/add_student.php')) ?>">Ajouter un etudiant</a>
    </div>

    <div class="grid grid-3">
        <div class="stat-card"><span>Total etudiants</span><strong data-stat="total_students"><?= h((string)$stats['total_students']) ?></strong></div>
        <div class="stat-card"><span>Etudiants inscrits</span><strong data-stat="registered_students"><?= h((string)$stats['registered_students']) ?></strong></div>
        <div class="stat-card"><span>Non inscrits</span><strong data-stat="not_registered_students"><?= h((string)$stats['not_registered_students']) ?></strong></div>
        <div class="stat-card"><span>Total factures</span><strong data-stat="total_invoices"><?= h((string)$stats['total_invoices']) ?></strong></div>
        <div class="stat-card"><span>Montant attendu</span><strong data-stat="total_expected_amount"><?= money($stats['total_expected_amount']) ?></strong></div>
        <div class="stat-card"><span>Montant paye</span><strong data-stat="total_paid_amount"><?= money($stats['total_paid_amount']) ?></strong></div>
        <div class="stat-card"><span>Montant impaye</span><strong data-stat="total_unpaid_amount"><?= money($stats['total_unpaid_amount']) ?></strong></div>
        <div class="stat-card"><span>Paiements en attente</span><strong data-stat="pending_payments"><?= h((string)$stats['pending_payments']) ?></strong></div>
        <div class="stat-card"><span>Factures en retard</span><strong data-stat="late_invoices"><?= h((string)$stats['late_invoices']) ?></strong></div>
    </div>

    <div class="page-header" style="margin-top:24px">
        <h2>Paiements en attente</h2>
        <a class="btn btn-secondary" href="<?= h(url('admin/payments.php?status=pending')) ?>">Tout voir</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
            <tr>
                <th>Reference</th>
                <th>Matricule</th>
                <th>Facture</th>
                <th>Montant</th>
                <th>Statut</th>
                <th></th>
            </tr>
            </thead>
            <tbody data-admin-pending-payments>
            <?php foreach ($pendingPayments as $payment): ?>
                <tr>
                    <td><?= h($payment['payment_reference']) ?></td>
                    <td><?= h($payment['matricule']) ?></td>
                    <td><?= h($payment['invoice_number']) ?></td>
                    <td><?= money($payment['amount']) ?></td>
                    <td><?= badge($payment['status']) ?></td>
                    <td><a class="btn btn-secondary btn-small" href="<?= h(url('admin/validate_payment.php?id=' . $payment['id'])) ?>">Examiner</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
