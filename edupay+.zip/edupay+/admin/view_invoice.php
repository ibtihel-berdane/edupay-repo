<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/admin_auth.php';

// Agent invoice detail page with invoice items and payment history.
$invoiceId = (int)($_GET['id'] ?? 0);
sync_invoice_status($invoiceId);
$invoice = query_one(
    "SELECT i.*, s.matricule, s.first_name, s.last_name, s.program, s.level, s.academic_year
     FROM invoices i
     JOIN students s ON s.id = i.student_id
     WHERE i.id = ?",
    [$invoiceId]
);
if (!$invoice) {
    flash('danger', 'Facture introuvable.');
    redirect('admin/invoices.php');
}

$items = query_all('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY fee_type ASC, id ASC', [$invoiceId]);
$payments = query_all(
    "SELECT p.*, ii.fee_name, r.id AS receipt_id
     FROM payments p
     LEFT JOIN invoice_items ii ON ii.id = p.invoice_item_id
     LEFT JOIN receipts r ON r.payment_id = p.id
     WHERE p.invoice_id = ?
     ORDER BY p.submitted_at DESC",
    [$invoiceId]
);

$pageTitle = 'Voir facture';
$layout = 'admin';
$active = 'invoices';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
    <div>
        <h1><?= h($invoice['invoice_number']) ?></h1>
        <p class="muted"><?= h($invoice['matricule'] . ' - ' . $invoice['first_name'] . ' ' . $invoice['last_name']) ?></p>
    </div>
    <div class="actions">
        <button class="btn btn-secondary" type="button" onclick="window.print()">Imprimer</button>
        <a class="btn btn-secondary" href="<?= h(url('admin/invoice_pdf.php?id=' . $invoiceId)) ?>">Telecharger PDF</a>
        <a class="btn btn-secondary" href="<?= h(url('admin/invoices.php')) ?>">Retour</a>
    </div>
</div>

<div class="grid grid-4">
    <div class="stat-card"><span>Total</span><strong><?= money($invoice['total_amount']) ?></strong></div>
    <div class="stat-card"><span>Paye</span><strong><?= money($invoice['paid_amount']) ?></strong></div>
    <div class="stat-card"><span>Reste</span><strong><?= money($invoice['remaining_amount']) ?></strong></div>
    <div class="stat-card"><span>Statut</span><strong><?= badge($invoice['status']) ?></strong></div>
</div>

<div class="card" style="margin-top:18px">
    <div class="grid grid-3">
        <p><strong>Echeance</strong><br><?= h($invoice['due_date'] ?? '') ?></p>
        <p><strong>Matricule</strong><br><?= h($invoice['matricule']) ?></p>
        <p><strong>Filiere</strong><br><?= h(program_label($invoice['program'])) ?> / <?= h(level_label($invoice['level'])) ?></p>
    </div>
</div>

<div class="page-header" style="margin-top:24px"><h2>Elements de facture</h2></div>
<div class="table-wrap">
    <table>
        <thead><tr><th>Frais</th><th>Type</th><th>Montant</th><th>Paye valide</th><th>Reste disponible</th></tr></thead>
        <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?= h(fee_label($item['fee_name'])) ?></td>
                <td><?= badge($item['fee_type']) ?></td>
                <td><?= money($item['amount']) ?></td>
                <td><?= money(invoice_item_paid((int)$item['id'])) ?></td>
                <td><?= money(invoice_item_remaining((int)$item['id'])) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="page-header" style="margin-top:24px"><h2>Paiements</h2></div>
<div class="table-wrap">
    <table>
        <thead><tr><th>Reference</th><th>Cible</th><th>Montant</th><th>Methode</th><th>Statut</th><th>Soumis le</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($payments as $payment): ?>
            <tr>
                <td><?= h($payment['payment_reference']) ?></td>
                <td><?= h(fee_label($payment['fee_name'] ?? null)) ?></td>
                <td><?= money($payment['amount']) ?></td>
                <td><?= h(payment_method_label($payment['payment_method'])) ?></td>
                <td><?= badge($payment['status']) ?></td>
                <td><?= h($payment['submitted_at']) ?></td>
                <td class="receipt-cell">
                    <?php if ($payment['status'] === 'pending'): ?>
                        <a class="btn btn-secondary btn-small" href="<?= h(url('admin/validate_payment.php?id=' . $payment['id'])) ?>">Examiner</a>
                    <?php elseif ($payment['receipt_id']): ?>
                        <a class="btn btn-secondary btn-small" href="<?= h(url('admin/receipts.php?id=' . $payment['receipt_id'])) ?>">Recu</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
