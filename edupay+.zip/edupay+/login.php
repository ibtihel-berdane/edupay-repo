<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';
start_app_session();

// Shared login page: authenticates by matricule and opens either an agent or student session.
if (current_admin_id()) {
    redirect('admin/dashboard.php');
}
if (current_student_id()) {
    redirect('student/dashboard.php');
}

$matricule = '';
$errors = [];

if (is_post()) {
    verify_csrf();
    $matricule = trim((string)($_POST['matricule'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if ($matricule === '') {
        $errors[] = 'Le matricule est obligatoire.';
    }
    if ($password === '') {
        $errors[] = 'Le mot de passe est obligatoire.';
    }

    if (!$errors) {
        if (validate_student_matricule($matricule)) {
            $student = query_one('SELECT * FROM students WHERE matricule = ?', [$matricule]);
            if ($student && $student['password'] !== null && $student['account_status'] === 'registered' && password_verify($password, $student['password'])) {
                session_regenerate_id(true);
                clear_admin_session();
                $_SESSION['student_id'] = (int)$student['id'];
                $_SESSION['student_matricule'] = $student['matricule'];
                $_SESSION['student_name'] = $student['first_name'] . ' ' . $student['last_name'];
                redirect('student/dashboard.php');
            }
        } else {
            $admin = query_one(
                'SELECT * FROM admins WHERE matricule = ? OR admin_code = ?',
                [$matricule, strtoupper($matricule)]
            );
            if ($admin && password_verify($password, $admin['password'])) {
                session_regenerate_id(true);
                clear_student_session();
                $_SESSION['admin_id'] = (int)$admin['id'];
                $_SESSION['admin_code'] = $admin['admin_code'];
                $_SESSION['admin_matricule'] = $admin['matricule'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_role'] = $admin['role'];
                redirect('admin/dashboard.php');
            }
        }

        $errors[] = 'Matricule ou mot de passe incorrect.';
    }
}

$pageTitle = 'Connexion';
$layout = 'public';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap">
<div class="auth-brand"><i class="fa-solid fa-graduation-cap" style="color:var(--color-blue);"></i> <span class="brand-white">Edu</span><span class="brand-blue">Pay+</span></div>
    <section class="auth-card auth-card-wide">
        <div class="auth-heading">
            <h1><i class="fa-solid fa-right-to-bracket"></i> Connexion</h1>
            <p class="muted">Acces etudiants et agents comptables.</p>
        </div>
        <form method="post" novalidate>
            <?= csrf_field() ?>
            <?php foreach ($errors as $error): ?>
                <div class="alert alert-danger"><?= h($error) ?></div>
            <?php endforeach; ?>
            <div class="form-row">
                <label for="matricule"><i class="fa-solid fa-id-card"></i> Matricule</label>
                <input id="matricule" name="matricule" value="<?= h($matricule) ?>" autocomplete="username" placeholder="202400000000 ou ADM001" required>
            </div>
            <div class="form-row">
                <label for="password"><i class="fa-solid fa-lock"></i> Mot de passe</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required>
            </div>
            <div class="actions auth-actions">
                <button class="btn btn-primary" type="submit"><i class="fa-solid fa-arrow-right-to-bracket"></i> Se connecter</button>
            </div>
            <div class="auth-footer">
                Pas encore de compte ? <a href="<?= h(url('student/signup.php')) ?>">Inscrivez-vous</a>
            </div>
        </form>
    </section>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
